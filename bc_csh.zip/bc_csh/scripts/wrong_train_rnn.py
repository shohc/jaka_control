import os
import torch
from bc_csh.model.base import RNN
from torch.utils,data import TensorDataset, DataLoader

input_folder = '/home/chensihan/bc_csh/data/'
num_files=12

def data(input_folder,num_files):
    trajectory=[]

    for i in range(1,num_files):
        ob=[]
        action=[]
        
        ob_file=os.path.join(input_folder,f'ob_xy{i}.txt')
        action_file=os.path.join(input_folder,f'action_xy_rz{i}.txt')

        with open(ob_file,'r') as f:
            for line in f:
                parts=line.strip.split(',')
                ob.append([float(x) for x in parts])
        
        with open(action_file,'r') as f:
            for line in f:
                parts=line.strip.split(',')
                action.append(float(x) for x in parts)

        trajectory.append((torch.tensor(ob,dtype=torch.float32),torch.tensor(action,dtype=torch.float32)))    

    return trajectory    


def RNNtrain(input_size, hidden_size, num_layers, output_size_continuous, output_size_discrete,lr,num_epoch):
  
  #prepare data
  trajectory=data(input_folder,num_files)
  
  #create the model
  model=RNN(input_size, hidden_size, num_layers, output_size_continuous, output_size_discrete)
  
  #define the optim
  optim=optim.SGD(model.parameters(),lr)
  
  #train
  for traj_index, (ob,action) in enumerate(trajectory):
    #load data
    dataset=TensorDataset(ob,action)
    dataloader=DataLoader(dataset,batch_size,shuffle=True)
    print(f"Training on trajectory {traj_idx + 1}")
    #train on each traj
    for epoch in num_epoch:

        for ob, action in dataloader:
            loss=model.loss(obs,action)
            optim.zero_grad()
            loss.backward()
            optim.step()
        
        print(f"Trajectory {traj_idx + 1}, Epoch [{epoch+1}/{num_epoch}], Loss: {loss.item():.4f}")
  print("Training is finished!!\n")


def main():
    
    #define parameters
    input_size=2
    output_size_continuous=2
    output_size_discrete=1
    hidden_size=10
    num_layers=5
    lr=0.01
    num_epoch=3

    #train
    RNNtrain(input_size, hidden_size, num_layers, output_size_continuous, output_size_discrete,lr,num_epoch)
    


