import os
import torch
from model.base import RNN
from torch.utils.data import TensorDataset, DataLoader
import torch.optim as optim

input_folder = '/home/chensihan/bc_csh/data/'
num_files=12

def data(input_folder,num_files):
    trajectory=[]

    for i in range(1,num_files+1):
        ob=[]
        action=[]
        
        ob_file=os.path.join(input_folder,f'ob_xy{i}.txt')
        action_file=os.path.join(input_folder,f'action_xy_rz{i}.txt')

        with open(ob_file,'r') as f:
            for line in f:
                parts=line.strip().split(',')
                ob.append([float(x) for x in parts])
        
        with open(action_file,'r') as f:
            for line in f:
                parts=line.strip().split(',')
                action.append([float(x) for x in parts])
        
        try:
            ob_tensor = torch.tensor(ob, dtype=torch.float32)
            action_tensor = torch.tensor(action, dtype=torch.float32)
        except Exception as e:
            print(f"Error converting to tensor: {e}")
            continue  # 跳过错误的数据

        trajectory.append((ob_tensor, action_tensor))   

    return trajectory    


def RNNtrain(input_size, hidden_size, num_layers, output_size_continuous, output_size_discrete,lr,num_epoch,batch_size):
  
  #prepare data
  trajectory=data(input_folder,num_files)
  
  #create the model
  model=RNN(input_size, hidden_size, num_layers, output_size_continuous, output_size_discrete)
  
  #define the optim
  model_optim=optim.SGD(model.parameters(),lr)
  
  #train
  for epoch in range(num_epoch):
    model.train()
    for traj_index, (ob,action) in enumerate(trajectory):
     #load data    
     sequence_length = ob.shape[0]      
     
     # 添加 batch 维度
     ob = ob.unsqueeze(0)  # (1, sequence_length, input_size)
     action = action.unsqueeze(0)
     dataset=TensorDataset(ob,action)
     dataloader=DataLoader(dataset,batch_size,shuffle=False)
     print(f"Training on trajectory {traj_index + 1}")
     #train on each traj
           
     hidden= (torch.zeros(num_layers,batch_size, hidden_size),
                           torch.zeros(num_layers, batch_size, hidden_size))   
     
     for ob_batch, action_batch in dataloader:
        for num in range(sequence_length):
            #print(ob_batch.shape)>>torch.Size([1, 8, 2])
            #print(sequence_length)>>8
            obs=ob_batch[:,num,:].unsqueeze(0)
            actions=action_batch[:,num,:].unsqueeze(0)            
            loss,hidden_update=model.loss(obs,actions,hidden)
            with torch.no_grad():              
             hidden=(hidden_update[0].clone(),hidden_update[1].clone())
            model_optim.zero_grad()
            loss.backward()
            model_optim.step()
            print(f"loss{num+1}:{loss.item():.4f}")
            

     print(f"Trajectory {traj_index + 1}, Epoch [{epoch+1}/{num_epoch}], Loss: {loss.item():.4f}")
  
  print("Training is finished!!\n")


def main():
    
    #define parameters
    input_size=2
    output_size_continuous=2
    output_size_discrete=3
    hidden_size=100
    num_layers=10
    lr=0.1
    num_epoch=5
    batch_size=1

    #train
    RNNtrain(input_size, hidden_size, num_layers, output_size_continuous, output_size_discrete,lr,num_epoch,batch_size)
    
if __name__ == "__main__":
    main()

