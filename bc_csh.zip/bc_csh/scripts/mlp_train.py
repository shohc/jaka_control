import torch
import os
from torch.utils.data import TensorDataset
from model.base import MLP
from torch.utils.data import TensorDataset, DataLoader



# input_folder = '/home/chensihan/bc_csh/data/'
input_folder = '/home/chensihan/bc_csh/data4mlp/'
num_files=12



def data(input_folder,num_files):
    trajectory=[]

    for i in range(1,num_files+1):
        ob=[]
        action=[]
        
        ob_file=os.path.join(input_folder,f'ob_xy_mm{i}.txt')
        action_file=os.path.join(input_folder,f'action_xy_rz_mm{i}.txt')

        with open(ob_file,'r') as f:
            for line in f:
                parts=line.strip().split(',')
                ob.append([float(x) for x in parts])
        
        with open(action_file,'r') as f:
            for line in f:
                parts=line.strip().split(',')
                action.append([float(x) for x in parts])
        
        try:
            ob_tensor = torch.tensor(ob, dtype=torch.float32)
            action_tensor = torch.tensor(action, dtype=torch.float32)
        except Exception as e:
            print(f"Error converting to tensor: {e}")
            continue  # 跳过错误的数据

        trajectory.append((ob_tensor, action_tensor))   

    return trajectory    

def MLPtrain(in_dim,out_dim,hidden_dim,n_layers,activation:str,lr,num_epoch,batch_size):
   
  #prepare data
  trajectory=data(input_folder,num_files)

  #create the model
  model=MLP(in_dim, out_dim, hidden_dim, n_layers, activation,lr)
  
  #train
  for epoch in range(num_epoch):
    model.train()
    for traj_index, (ob,action) in enumerate(trajectory):
     #load data    
     sequence_length = ob.shape[0]          
     dataset=TensorDataset(ob,action)
     dataloader=DataLoader(dataset,batch_size,shuffle=False)
     print(f"Training on trajectory {traj_index + 1}")
     #train on each traj    
     
     for ob_batch, action_batch in dataloader:
             
            if torch.isnan(ob_batch).any() or torch.isnan(action_batch).any():
              raise ValueError("Input contains NaN")
                   
            loss=model.loss(ob_batch,action_batch)           
            print(f"loss:{loss}")#float has no attribute "item()""
            

     print(f"Trajectory {traj_index + 1}, Epoch [{epoch+1}/{num_epoch}], Loss: {loss}")
  
  print("Training is finished!!\n")
  torch.save(model.state_dict(), 'mlp_model.pth')
  print("The model has been saved")


def main():
    
    #define parameters
    input_size=2
    output_size=3    
    hidden_size=20
    num_layers=8
    activation='relu'
    lr=0.0001
    num_epoch=5
    batch_size=1

    #train
    MLPtrain(input_size, output_size, hidden_size, num_layers, activation,lr,num_epoch,batch_size)
    
if __name__ == "__main__":
    main()


  
