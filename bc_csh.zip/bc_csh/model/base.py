import torch
from torch import nn
import torch.optim as optim

_str_to_activation = {
    'relu': nn.ReLU(),
    'tanh': nn.Tanh(),
    'leaky_relu': nn.LeakyReLU(),
    'sigmoid': nn.Sigmoid(),
    'selu': nn.SELU(),
    'softplus': nn.Softplus(),
    'identity': nn.Identity(),
}

class MLP(nn.Module):
    def __init__(self,in_dim,out_dim,hidden_dim,n_layers,activation:str,learning_rate):
        super(MLP, self).__init__()
        self.layers=[]
        self.lr=learning_rate
        in_size=in_dim
        self.activation_function=_str_to_activation[activation]
        
        for _ in range(n_layers):
            self.layers.append(nn.Linear(in_size,hidden_dim))
            #self.layers.append(self.activation_function)
            in_size=hidden_dim
        
        self.layers.append(nn.Linear(hidden_dim,out_dim))
        #self.layers.append(self.activation_function)    
        
        self.model=nn.Sequential(*self.layers)
        self.optim=optim.SGD(self.model.parameters(),self.lr)
        self.loss_function=nn.MSELoss()
        #HuberLoss(output,target)
    def forward(self,obs):
        return self.model(obs)

    def loss(self,obs,actions):
        print(obs)
        print(actions)
        act_pre=self.forward(obs)
        print(act_pre)
        loss=self.loss_function(act_pre,actions)
        self.optim.zero_grad()
        loss.backward()
        self.optim.step()
        return loss.item()
        


class RNN(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size_continuous, output_size_discrete):
        super(RNN, self).__init__()
        
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc_continuous = nn.Linear(hidden_size, output_size_continuous)
        self.fc_discrete = nn.Linear(hidden_size, output_size_discrete)
        
        self.hidden = None

        self.criterion_rz = nn.CrossEntropyLoss()
        self.criterion_xy = nn.MSELoss()



    def forward(self, x, hidden):
        # Initialize hidden state if not done
               
        
        out, hidden = self.lstm(x, hidden)
        
        # 连续变量输出
        out_continuous = self.fc_continuous(out)  # Use the last time step's output
        
        # 离散变量输出，使用 softmax 激活函数
        out_discrete = self.fc_discrete(out)  # Use the last time step's output
         # 使用 softmax 获取离散变量的概率分布
        
        return out_continuous, out_discrete, hidden

    def loss(self,obs,action,hidden):
        pre_xy,pre_rz,hidden_update=self.forward(obs,hidden)
        #print(pre_rz.shape)
        print(pre_xy)
        pre_rz = pre_rz.view(-1, pre_rz.size(-1))
        loss_rz=self.criterion_rz(pre_rz,action[:, :, 2].view(-1).long())
        loss_xy=self.criterion_xy(pre_xy,action[:, :, :2])
        k1=1
        k2=1
        return k1*loss_rz+k2*loss_xy,hidden_update










