import os

# 输入文件夹和输出文件夹的路径
input_folder = '/home/chensihan/bc_csh/orginal_data/'
output_folder = '/home/chensihan/bc_csh/data/'

def process_files(input_folder, output_folder, num_files,flag):
    try:
        # 遍历处理每个文件
        for i in range(1, num_files + 1):
            input_file = os.path.join(input_folder, f'ob{i}.txt')
            output_file = os.path.join(output_folder, f'ob_xy_mm{i}.txt')

            # 打开输入文件以读取
            with open(input_file, 'r') as infile:
                # 打开输出文件以写入
                with open(output_file, 'w') as outfile:
                    # 遍历输入文件的每一行
                    for line in infile:
                        # 去掉每行末尾的换行符，并按逗号分割
                        parts = line.strip().split(',')
                        # 只取前两列，并写入新文件
                        if len(parts) >= 2:
                            x = float(parts[0])#str
                            y = float(parts[1])#str
                            if flag == 1:
                                x *= 1000
                                y *= 1000
                            outfile.write(f"{x},{y}\n")
            
            print(f"文件 {input_file} 处理完成，结果已写入到 {output_file}")

    except FileNotFoundError:
        print(f"文件 {input_file} 不存在，请检查路径是否正确。")
    except Exception as e:
        print(f"发生错误：{e}")

# 主函数，用于调用处理文件的函数
def main():
    num_files = 15  # 处理文件的数量，这里假设有15个文件
    #whether transfer from "m" to "mm"
    flag=1
    process_files(input_folder, output_folder, num_files,flag)

if __name__ == "__main__":
    main()
