import os

# 输入文件夹和输出文件夹的路径
input_folder = '/home/chensihan/bc_csh/orginal_data/'
output_folder = '/home/chensihan/bc_csh/data4mlp/'

def output_process(input_folder, output_folder, num_files,label,flag):
    try:
        for i in range(1, num_files + 1):
            input_file = os.path.join(input_folder, f'action{i}.txt')
            output_file = os.path.join(output_folder, f'action_xy_rz_mm{i}.txt')

            lines = []  # 存储处理后的每行数据
            last_processed_line = None  # 记录最后一行处理后的内容

            # 读取文件内容
            with open(input_file, 'r') as infile:
                # 跳过第一行
                next(infile)
                
                # 读取每一行数据并进行处理
                for line_number, line in enumerate(infile, start=2):  # 从第二行开始计数
                    parts = line.strip().split(',')
                    
                    # 检查是否符合预期的数据格式
                    if len(parts) < 6:
                        print(f"警告：文件 {input_file} 中的第 {line_number} 行数据不完整或格式错误：{line}")
                        continue  # 跳过当前行并继续处理下一行
                    
                    try:
                        # 只保留第1、2和6列数据
                        
                        if label==1:
                        # 根据第6列的值的范围用不同的值替换
                         value_six = float(parts[5])  # 假设第六列为浮点数
                         if 120 <= value_six < 135:
                            filtered_parts[2] = '0'  # 转换为字符串
                         elif 30 <= value_six < 50:
                            filtered_parts[2] = '1'  # 转换为字符串
                         else:
                            filtered_parts[2] = '2'  # 转换为字符串
                        x = float(parts[0])
                        y = float(parts[1])    
                        if flag==1:
                            x*=1000 
                            y*=1000                
                        parts[0] = str(x)
                        parts[1] = str(y)
                        filtered_parts = [parts[0], parts[1], parts[5]]
                        # 添加处理后的行数据
                        lines.append(','.join(filtered_parts))
                        
                        # 记录最后一行的处理内容
                        last_processed_line = ','.join(filtered_parts)
                    except Exception as e:
                        print(f"处理文件 {input_file} 第 {line_number} 行时发生错误：{e}")
            
            # 添加复制的最后一行到末尾
            if last_processed_line:
                lines.append(last_processed_line)
            
            # 写入处理后的数据到输出文件
            with open(output_file, 'w') as outfile:
                for line in lines:
                    outfile.write(f"{line}\n")
            
            print(f"文件 {input_file} 处理完成，结果已写入到 {output_file}")

    except FileNotFoundError:
        print(f"文件 {input_file} 不存在，请检查路径是否正确。")
    except Exception as e:
        print(f"发生错误：{e}")
def input_process(input_folder, output_folder, num_files,flag):
    try:
        for i in range(1, num_files + 1):
            input_file = os.path.join(input_folder, f'action{i}.txt')
            output_file = os.path.join(output_folder, f'action_input{i}.txt')

            with open(input_file, 'r') as infile:
                lines = infile.readlines()

               
               

                # 修改第一行
                if lines:
                    first_line_parts = lines[0].strip().split(',')
                    if len(first_line_parts) >= 6:
                        first_line_parts[0] = '0'
                        first_line_parts[1] = '0'
                        first_line_parts[5] = '0'
                        lines[0] = ','.join(first_line_parts) + '\n'

                processed_lines = []

                for line in lines:
                    parts = line.strip().split(',')
                    if len(parts) >= 6:
                        x = float(parts[0])
                        y = float(parts[1])
                        if flag == 1:
                            x *= 1000
                            y *= 1000
                        parts[0] = str(x)
                        parts[1] = str(y)

                        filtered_parts = [parts[0], parts[1], parts[5]]

                        

                        processed_lines.append(','.join(filtered_parts))

                # 将处理后的数据写入输出文件
                with open(output_file, 'w') as outfile:
                    outfile.write('\n'.join(processed_lines))

            print(f"文件 {input_file} 处理完成，结果已写入到 {output_file}")

    except FileNotFoundError:
        print(f"文件 {input_file} 不存在，请检查路径是否正确。")
    except Exception as e:
        print(f"发生错误：{e}")   

# 主函数，用于调用处理文件的函数
def main():
    num_files = 15  # 处理文件的数量，假设有15个文件
    #whether use class label
    label=0
    #whether transfer from "m" to "mm"
    flag=1
    # input_process(input_folder, output_folder, num_files,flag)
    output_process(input_folder, output_folder, num_files,label,flag)

if __name__ == "__main__":
    main()
