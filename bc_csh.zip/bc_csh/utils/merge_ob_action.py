import os
input_folder = '/home/chensihan/bc_csh/data4mlp/'
output_folder = '/home/chensihan/bc_csh/data4mlp/'
target='-443.252,15.5574'

def file2(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    # 删除最后一行
    lines = lines[:-1]
    # 在第一行补0,0,0
    lines.insert(0, '0,0,0\n')
    return lines

def merge(input_folder,output_folder,num_files,flag):
    for i in range(1,num_files+1):
        input_file1=os.path.join(input_folder,f'ob_xy_mm{i}.txt')
        input_file2=os.path.join(input_folder,f'action_input{i}.txt')
        outfile=os.path.join(output_folder,f'ob_action{i}.txt')
        
        with open(input_file1,'r') as file1, open(input_file2,'r') as file2,open(outfile,'w') as output:
          for line1,line2 in zip(file1,file2):
            if flag==1:
             output.write(line1.strip() + ',' + line2.strip() + ','+target+'\n')
            else:
             output.write(line1.strip() + ',' + line2.strip() +'\n')
def main():
    num_files = 12  # 处理文件的数量，这里假设有15个文件
    #whether to merge target position
    flag=0
    merge(input_folder, output_folder, num_files,flag)
    print("finish")

if __name__ == "__main__":
    main()

    


