import torch

def array2tensor(array):
    return torch.from_numpy(array)